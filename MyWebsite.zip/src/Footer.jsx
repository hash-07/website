import React from "react";

const Footer = () => {
	return (
	<div>
		<footer className="w-100 bg-light text-center">
		<p> Copyright © 2020 Code with Hash. All Rights Reserved | Terms & Conditions.

		</p>

		</footer>


	</div>
		);
};


export default Footer;