import web from "../src/web.jpeg";
import ai from "../src/ai.jpeg";
import coffee from "../src/coffee.jpg";
import digital from "../src/digital.jpg";
import ethical from "../src/ethical.png";
import ml from "../src/ml.jpg";

import hd from "../src/hd.jpg";

const Sdata = [
{
	imgsrc : web,
	title : "Web Development",

},

{
	imgsrc : ai,
	title : "Artificial Intelligence",

},

{
	imgsrc : digital,
	title : "Digital Marketing",

},

{
	imgsrc : ethical,
	title : "Ethical Hacking",

},

{
	imgsrc : ml,
	title : "Machine Learning",

},



{
	imgsrc : hd,
	title : "Hardware & Networking",

}
]

export default Sdata;